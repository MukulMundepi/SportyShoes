package com.luv2code.service;

public class AdminService {

}
